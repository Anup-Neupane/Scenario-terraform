import json
import boto3
import os

s3 = boto3.client('s3')

def handler(event, context):
    """
    Simple Lambda function to process S3 uploads
    """
    print("Lambda function started!")
    print(f"Event: {json.dumps(event)}")
    
    # Get bucket name from environment
    bucket_name = os.environ.get('BUCKET')
    print(f"Bucket: {bucket_name}")
    
    # Process each uploaded file
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        
        print(f"Processing file: s3://{bucket}/{key}")
        
        # Get the file from S3
        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            content = response['Body'].read().decode('utf-8')
            
            print(f"File content: {content}")
            print("✓ File processed successfully!")
            
        except Exception as e:
            print(f"✗ Error: {str(e)}")
            raise
    
    return {
        'statusCode': 200,
        'body': json.dumps('Success!')
    }
